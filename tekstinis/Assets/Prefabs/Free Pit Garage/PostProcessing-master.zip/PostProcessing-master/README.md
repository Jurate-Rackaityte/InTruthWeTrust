# Post-processing Stack

Need help ? Check out the [quick start guide](https://github.com/Unity-Technologies/PostProcessing/wiki) and [the official forums](https://forum.unity3d.com/forums/image-effects.96/) !

Found a bug ? Let us know and [post an issue](https://github.com/Unity-Technologies/PostProcessing/issues) !
